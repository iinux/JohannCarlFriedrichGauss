<?php
$filename="/temp/sosofile.txt.gz";
$zd=gzopen($filename,"r");
$contents=gzread($zd,10000);
gzclose($zd);
?>
